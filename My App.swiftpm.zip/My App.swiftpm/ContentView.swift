import SwiftUI
import SceneKit

struct ContentView: View {
    let quotes = [
        "Life is what happens when you're busy making other plans.",
        "The future belongs to those who believe in the beauty of their dreams.",
        "Success is not final, failure is not fatal.",
        "The only way to do great work is to love what you do.",
        "Stay hungry, stay foolish.",
        "Innovation distinguishes between a leader and a follower.",
        "The best way to predict the future is to create it.",
        "Everything you've ever wanted is on the other side of fear."
    ]
    
    @State private var currentQuote: String = "Click for a quote!"
    
    var body: some View {
        ZStack {
            LinearGradient(colors: [.blue, .green, .blue, .cyan], 
                           startPoint: .top, 
                           endPoint: .bottom)
            
            VStack {
                SceneView(
                    scene: {
                        let scene = SCNScene(named: "fish.usdz")
                        scene?.background.contents = UIColor.clear
                        return scene
                    }(),
                    options: [.allowsCameraControl, .autoenablesDefaultLighting]
                )
                .frame(width: 350, height: 300)
                .cornerRadius(50)
                
                Text("Jasper")
                    .bold()
                    .font(.system(size: 40))
                    .foregroundColor(.white)
                    .padding()
                
                VStack {
                    InfoView(imageName: "mail.stack", text: "123@gmail.com")
                    InfoView(imageName: "globe.americas.fill", text: "ABC")
                    InfoView(imageName: "location.circle.fill", text: "USA")
                    
                    // Quote Display
                    Text(currentQuote)
                        .foregroundColor(.white)
                        .font(.system(size: 16))
                        .italic()
                        .multilineTextAlignment(.center)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.black.opacity(0.2))
                        .cornerRadius(15)
                        .padding()
                    
                    Button(action: {
                        withAnimsation {
                            currentQuote = quotes.randomElement() ?? ""
                        }
                    }) {
                        HStack {
                            Image(systemName: "quote.bubble.fill")
                            Text("Generate Quote")
                        }
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue.opacity(0.5))
                        .cornerRadius(15)
                    }
                    .padding(.bottom)
                }
            }
        }
        .ignoresSafeArea()
    }
    struct InfoView: View {
        let imageName: String
        let text: String
        
        var body: some View {
            HStack {
                Image(systemName: imageName)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 33, height: 33)
                    .foregroundColor(.white)
                    .padding()
                
                Text(text)
                    .foregroundColor(.white)
                    .font(.system(size: 18))
            }
            .padding(.horizontal)
        }
    }
    
    
    
}
